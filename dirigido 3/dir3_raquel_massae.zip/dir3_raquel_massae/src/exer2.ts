var cont: number;

for (cont = 5; cont <= 11; cont++) {
    console.log("Número: " + cont);
}