var cont: number;

for (cont = 1; cont <= 11; cont++) {
    console.log("Número: " + cont);
}