for (let i: number = 20; i >= 0; i -=2) {
    console.log(i);
}