for (let i: number = 8; i <= 120; i += 12) {
    console.log(i);
}