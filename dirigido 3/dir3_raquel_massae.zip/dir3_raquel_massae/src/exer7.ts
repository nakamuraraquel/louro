var i:number = 1;
var soma:number = 0;

while(i<11){
    console.log(i);
    soma += i;
    i++;
}

console.log("Soma: ",soma);

export default{};