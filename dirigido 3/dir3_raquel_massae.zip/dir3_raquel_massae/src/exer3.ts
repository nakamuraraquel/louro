for (let i:number = 4; i <= 23; i++) {
    console.log("Número: ",i);
}