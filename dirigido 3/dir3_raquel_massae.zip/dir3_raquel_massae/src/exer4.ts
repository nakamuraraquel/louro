for (let i: number = 5; i <= 50; i += 5) {
    console.log(i);
}