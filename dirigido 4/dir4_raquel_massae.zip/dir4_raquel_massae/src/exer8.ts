const numint: number[] = Array(20);

for (let x: number = 0; x < 20; x++) {
    numint[x] = Math.floor(Math.random() * 100 + 1)
}

console.log(numint);

numint.sort(function(a, b){return a-b});

console.log(numint);