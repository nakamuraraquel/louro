var cidades:string[] = ["São Paulo", "Rio de Janeiro", "Salvador", "Belo Horizonte", "Porto Alegre","Jacareí","São José dos Campos"];
for(var i = 0;i < cidades.length;i++){
  	console.log("Gostaria de visitar a cidade:",cidades[i]);
}