const nomes:string[] = ["Ana","Maria","José","João","Alice"];

for(let i:number = 0; i<nomes.length;i++){
    console.log("Conheço alguém chamado(a):",nomes[i]);
}

export default{};