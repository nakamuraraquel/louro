var vetor: number[] = [];

for (var x: number = 0; x < 5; x++) {
    vetor[x] = Math.floor(Math.random() * 100 + 1)
}

console.log(vetor[3]);